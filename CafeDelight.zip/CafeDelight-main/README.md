# Cafe Delight
This is a website I made with a group partner for a Web and Database Design module at University. It is based around a local cafe that we hypothesized. 
The full zip and sql database is available to be downloaded. This is a fully functioning website with dynamically displayed information from a MySQL Database.
